
let Asteroids = function() {
    let canvas;
	let ctx;

	let HEIGHT;// = 500;
	let WIDTH ;//= 500;
	let timeWhenGameStarted = Date.now();   //return time in ms
 
	let frameCount = 0;
 
	let score = 0;
	
	let img={};
	img.spaceship=new Image();
	img.spaceship.src="img/spaceship.png";
	

	img.asteroid=new Image();
	img.asteroid.src="img/asteroids.png";
	
	
	img.space=new Image();
	img.space.src="img/space.png";
	
	
	img.bullet=new Image();
	img.bullet.src="img/bullet.png";
	

	let spaceship = {
			x:50,
			spdX:30,
			y:40,
			spdY:5,
			name:"spaceship",
			hp:3,
			width:60,
			height:70,
			img:img.spaceship,
			
			//
			atkSpd:1,
			attackCounter:0,
			spriteAnimCounter:0,
			pressingDown:false,
			pressingUp:false,
			pressingLeft:false,
			pressingRight:false,
			presingSpace:false,
			num:0,
			
		};
 
	let asteroidList = {};
	let bulletList = {};


     let initModule = function() {
        this.canvas = document.getElementById("canvas");
		 ctx= this.canvas.getContext("2d");
		 ctx.fillStyle = 'white';
		 HEIGHT=this.canvas.height;
		 WIDTH=this.canvas.width;
		
    };
	

 
	getDistanceBetweenEntity = function (entity1,entity2){  //return distance (number)
        let vx = entity1.x - entity2.x;
        let vy = entity1.y - entity2.y;
        return Math.sqrt(vx*vx+vy*vy);
		}
 
		testCollisionEntity = function (entity1,entity2){       //return if colliding (true/false)
			let rect1 = {
					x:entity1.x-entity1.width/2,
					y:entity1.y-entity1.height/2,
					width:entity1.width,
					height:entity1.height,
					}
			let rect2 = {
					x:entity2.x-entity2.width/2,
					y:entity2.y-entity2.height/2,
					width:entity2.width,
					height:entity2.height,
					}
			return testCollisionRectRect(rect1,rect2);
       
			}
 
	asteroid = function (id,x,y,spdX,spdY,width,height,size){
			let asteroid3 = {
					x:x,
					spdX:spdX,
					y:y,
					spdY:spdY,
					name:"asteroid",
					id:id,
					width:width,
					height:height,
					img:img.asteroid,
					size:size,
					spriteAnimCounter:0,
					};
			asteroidList[id] = asteroid3;
       
		}
 
	randomlyGenerateasteroid = function(){
			let x = Math.random()*WIDTH;
			let y = Math.random()*HEIGHT;
			let size=8;
			let height = 10*size;
			let width = 10*size;
			let id = Math.random();
			let spdX = 5 + Math.random() * 5;
			let spdY = 5 + Math.random() * 5;
			asteroid(id,x,y,spdX,spdY,width,height,size);
		   
	}
	
	Generateasteroid = function(x1,y1,size1){
			let x = x1;
			let y = y1;
			let size=size1;
			let height = 10*size;
			let width = 10*size;
			let id = Math.random();
			let spdX = 5 + Math.random() * 5;
			let spdY = 5 + Math.random() * 5;
			asteroid(id,x,y,spdX,spdY,width,height,size);
	}

	 
	Bullet = function (id,x,y,spdX,spdY,width,height){
			let asd = {
					x:x,
					spdX:spdX,
					y:y,
					spdY:spdY,
					name:"bullet",
					id:id,
					width:width,
					height:height,
					img:img.bullet,
					spriteAnimCounter:0,

					//
					timer:0,
			};
			bulletList[id] = asd;
	}
	 
	randomlyGenerateBullet = function(){
			let x = spaceship.x;
			let y = spaceship.y;
			let height = 30;
			let width = 40;
			let id = Math.random();
		   
			let angle =Math.random()*360; 
			let spdX = Math.cos(angle/180*Math.PI)*5;
			let spdY = Math.sin(angle/180*Math.PI)*5;
			Bullet(id,x,y,spdX,spdY,width,height);
	}
	 
	updateEntity = function (something){
			updateEntityPosition(something);
			something.spriteAnimCounter++;
			if(something.name=="spaceship")
				drawSpaceship(something);
			else
				drawEntity(something);
	}
	 
	updateEntityPosition = function(something){
			something.x += something.spdX;
			something.y += something.spdY;
			
			if(something.x>WIDTH)
					something.x=0;
			if(something.x<0)
					something.x=WIDTH;
			if(something.y>HEIGHT)
					something.y=0;
			if(something.y<0)
					something.y=HEIGHT;
	}
	 
	testCollisionRectRect = function(rect1,rect2){
			return rect1.x <= rect2.x+rect2.width
					&& rect2.x <= rect1.x+rect1.width
					&& rect1.y <= rect2.y + rect2.height
					&& rect2.y <= rect1.y + rect1.height;
	}
	 
	 drawEntity = function(something)
	 {
			ctx.save();
			let k;
			if(something.name=="asteroid")
				 k=8;
			else 
				k=7;
			
			let x=something.x-something.width/2;
			let y=something.y-something.height/2;
			let frameWidth=something.img.width/k;
			let frameHeight=something.img.height/k;
			
			let flyingMod=something.spriteAnimCounter%k;
			
			for(let i=0;i<k;i++)
			{
			ctx.drawImage(something.img,flyingMod*frameWidth,i*frameHeight,frameWidth,frameHeight,x,y,something.width,something.height);
			ctx.restore();
			}
	}
	drawSpaceship = function(something){
			ctx.save();
			let x=something.x-something.width/2;
			let y=something.y-something.height/2;
			let frameWidth=something.img.width/3;
			let frameHeight=something.img.height/8;
		
			ctx.drawImage(something.img,0,frameHeight*spaceship.num,frameWidth,frameHeight,x,y,something.width,something.height);
			ctx.restore();
		
	}
	
	drawBackground=function()
	{
		
		ctx.drawImage(img.space,0,0,WIDTH,HEIGHT);
	}
	 
	document.onkeydown = function(event){
			if(event.keyCode === 39)        //right arrow
					spaceship.pressingRight = true;
			else if(event.keyCode === 40)   //down arrow
					spaceship.pressingDown = true;
			else if(event.keyCode === 37) //left arrow
					spaceship.pressingLeft = true;
			else if(event.keyCode === 38) //up arrow 
					spaceship.pressingUp = true;
			else if(event.keyCode === 32) //space bar
					spaceship.pressingSpace = true;	
			
	}
	 
	document.onkeyup = function(event){
			if(event.keyCode === 39)        //right arrow
					spaceship.pressingRight = false;
			else if(event.keyCode === 40)   //down arrow
					spaceship.pressingDown = false;
			else if(event.keyCode === 37) //left arrow
					spaceship.pressingLeft = false;
			else if(event.keyCode === 38) //up arrow 
					spaceship.pressingUp = false;
			else if(event.keyCode === 32) //space bar
					spaceship.pressingSpace = false;	
	}
	 
	updatespaceshipPosition = function(){
			if(spaceship.pressingRight)
			{
					spaceship.x += 10;
					spaceship.num=2;
					spaceship.aimAngle-=45;
			}
			if(spaceship.pressingLeft)
			{
					spaceship.x -= 10;
					spaceship.num=5;
					spaceship.aimAngle+=45;
			}
			if(spaceship.pressingDown)
			{
					spaceship.y += 10;
					spaceship.num=7;
			}
			if(spaceship.pressingUp)
			{
					spaceship.y -= 10;
					spaceship.num=0;
			}
			if(spaceship.pressingSpace)
			{
						if(spaceship.attackCounter >25){  //every 1 sec
							randomlyGenerateBullet();
							spaceship.attackCounter = 0;
						}
			}
			
			if(spaceship.pressingRight&&spaceship.pressingUp)
				spaceship.num=1;
			if(spaceship.pressingRight&&spaceship.pressingDown)
				spaceship.num=3;
			if(spaceship.pressingLeft&&spaceship.pressingUp)
				spaceship.num=4;
			if(spaceship.pressingLeft&&spaceship.pressingDown)
				spaceship.num=6;

		  //update direction on canvs
		  if(spaceship.x>WIDTH)
				spaceship.x=0;
		  if(spaceship.x<0)
				spaceship.x=WIDTH;
		 if(spaceship.y>HEIGHT)
				spaceship.y=0;
		  if(spaceship.y<0)
				spaceship.y=HEIGHT;
		
	}
	 
	update = function(){
			ctx.clearRect(0,0,WIDTH,HEIGHT);
			drawBackground();
			frameCount++;
			score++;
		   
			if(frameCount % 100 === 0)     
					randomlyGenerateasteroid();
	 
		   
			spaceship.attackCounter += spaceship.atkSpd;
		   
		   
			for(let key in bulletList){
					updateEntity(bulletList[key]);
				   
					let toRemove = false;
					bulletList[key].timer++;
					if(bulletList[key].timer > 75){
							toRemove = true;
					}
				   
					for(let key2 in asteroidList){
							let isColliding = testCollisionEntity(bulletList[key],asteroidList[key2]);
							if(isColliding){
								if(asteroidList[key2].size==2)
								{
									toRemove = true;
									delete asteroidList[key2];
									delete bulletList[key];
									break;
								}
								else
								{
									Generateasteroid(asteroidList[key2].x,asteroidList[key2].y,asteroidList[key2].size/2);
									Generateasteroid(asteroidList[key2].x,asteroidList[key2].y,asteroidList[key2].size/2);
									delete asteroidList[key2];
									delete bulletList[key];
									break;
								}
								
							}                      
					}
					if(toRemove){
							delete bulletList[key];
					}
			}
		   
		   
			for(let key in asteroidList){
					updateEntity(asteroidList[key]);
				   
					let isColliding = testCollisionEntity(spaceship,asteroidList[key]);
					if(isColliding){
							delete asteroidList[key];
							spaceship.hp = spaceship.hp - 1;
					}
			}
			if(spaceship.hp <= 0){
					let timeSurvived = Date.now() - timeWhenGameStarted;           
					console.log("You lost! You survived for " + timeSurvived + " ms.");  
					startNewGame();
			}
			updatespaceshipPosition();
			drawSpaceship(spaceship);
			

			ctx.fillText(spaceship.hp + " Life:",0,30);
			ctx.fillText('Time: ' + score,200,30);
	}
	 
	startNewGame = function(){
			spaceship.hp = 3;
			timeWhenGameStarted = Date.now();
			frameCount = 0;
			score = 0;
			asteroidList = {};
			bulletList = {};
			
			for(let i=0; i<4;i++)
				randomlyGenerateasteroid();
	}
	 
	startNewGame();
	 
	setInterval(update,40);
	 

	
	 return {initModule};
}();